<?php

<html>
     <head>
          <title>Kit Guess</title>
          <link rel="stylesheet" type="text/css" href="stylesheet.css" />
     </head>
     <body>
          <div class='header'>
                             <header>
                                    <h1> Welcome</h1>
                             </header>
          </div>
          <div class='nav'>
                      <nav>
                         
                           <a href=>Blog</a>
                           <a href=> More Games</a>
                           <a href='tax.php'> Tax calculator</a>
                      </nav>
           </div>
          <h2>Name a PHP variable</h2>
          <form action="dat.php" method="POST">
             Guess: <input type="text" name="guess"> </br>
             <input type="submit" name="submit" value="Guess">
          </form>
     </body>
</html>
?>
