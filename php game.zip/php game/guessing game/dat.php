<?php
$random = rand('string', 'integer', 'float');

$guess = $_POST['guess'];
$submit = $_POST['submit'];

if(isset($submit)){
    if($guess=rand('string', 'integer', 'float')){
        echo 'You did it good';
    }
    else($guess!=rand('string', 'integer', 'float')){
        print 'You may rethink! >)'
    }
}

else{
    header("Location: game.php")
    exit();
}
