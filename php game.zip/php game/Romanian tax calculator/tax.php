<?php

<?php
$cost = array('1');
$sell = array('2');
define("TVA", 19*100);

$cost= $_POST['Cost of Production'];
$sell= $_POST['Additional tax'];

if( null !==$cost && null !== $sell) {
    
  echo $cost+$sell;
  }
else {
     echo 'Error';
     }
?>