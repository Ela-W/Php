<?php
namespace Magtest/App 

class Request{
     public function request($var, $url=null) {
        $uri= strlen($_SERVER['REQUEST_URI']);
        $response=parse_url($_GET['GET_URI']);
        return $response;
    }
}