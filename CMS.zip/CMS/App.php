<?php


namespace Magtest/App

class App {
    private $Request;
    private $Response;
    private $Router;
    
    public function __construct(){
        $this->request=$Request;
        $this->response=$Response;
        $this->router=$Router;
    }
}