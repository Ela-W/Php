<?php
namespace Magtest/App 

class Router {
    private $routes;
    
    public function __construct(){
        $this->Routes=$routes;
    }
    
    public function start(){
        
    }
}