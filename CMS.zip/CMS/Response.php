<?php
namespace Magtest/App 

class Response {
    public function response(){
        
        $uri= http_response_code($url);
        
        return $uri;
    }
}